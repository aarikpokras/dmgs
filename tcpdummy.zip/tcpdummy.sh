#!/bin/bash
clear&&sudo tcpdump -a -s0 -vv