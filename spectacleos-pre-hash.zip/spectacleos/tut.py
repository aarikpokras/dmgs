input("Welcome to spectacleOS! Here is a short tutorial explaining how to use it. Press enter to continue.")
input("To run a command, type it in and hit enter. Maybe try a command like `help`! Press enter to continue.")
input("Now you're ready for a great spectacle adventure! After this, once you're back in the bash shell, run `./specs` to run spectacleOS! Press enter to exit.")
