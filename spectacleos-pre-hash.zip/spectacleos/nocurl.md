## Why you should get releases from the Releases page rather than the code tab
Well, there's lots of reasons, but the main one is because the actual, full repo doesn't have the latest official version. So, if you download from the code tab, files might be corrupt, and all that stuff. And, also, I don't constantly update the README with the latest zips, so you should download it from the releases page. 

Thx<br />
Aarik 😀

<a href = "https://github.com/aarikpokras/spectacleos"><img src = "https://i.ibb.co/tCh8H8W/iconmonstr-home-6.png" width = "30" /></a>
