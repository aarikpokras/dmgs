# insert version here and import var from here to start.py
ver="Fuji v3.2.0"
